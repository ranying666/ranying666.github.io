## 使用说明  

Knowage中文汉化补丁   

由Knowage中文社区出品(QQ群:158245788)  

资源对应版本号 : 7.1.7  

请确保在Tomcat根路径下运行本程序   

如 E:\\Program Files\\Knowage-Server-CE   

汉化操作步骤详见：https://ranying666.github.io/2019/08/18/knowage-zh-patch/  

-------------------------------------------------

下面开始安装：

执行补丁输入 Y，回滚补丁输入 N , 取消输入 E   

